declare module 'react-native-mime-types';
declare module 'expo-barcode-scanner';
