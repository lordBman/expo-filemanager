export default function removeFileFolder() {}
